<?php
/* $sdate = $_POST['sdate'];
 $username = mysqli_real_escape_string($db, $_POST['username']);
 if($sdate){
  echo $query = "UPDATE users SET registered_session=(select sessionID from sessions WHERE date = $sdate) 
  WHERE username =$username";
mysqli_query($db, $query);  
 }
 ?>

