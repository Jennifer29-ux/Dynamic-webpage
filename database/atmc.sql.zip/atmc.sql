-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 22, 2020 at 11:53 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atmc`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
CREATE TABLE IF NOT EXISTS `booking` (
  `studentID` int(11) DEFAULT NULL,
  `sessionID` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`studentID`, `sessionID`) VALUES
(2, 2),
(2, 2),
(2, 10),
(2, 11),
(2, 11),
(2, 11),
(2, 2),
(2, 2),
(2, 2),
(2, 2),
(2, 2),
(2, 2),
(2, 7),
(2, 15),
(3, 7),
(2, 2),
(2, 14),
(2, 2),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `sessionz`
--

DROP TABLE IF EXISTS `sessionz`;
CREATE TABLE IF NOT EXISTS `sessionz` (
  `sdate` date NOT NULL,
  `day` varchar(20) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `tutor` varchar(50) NOT NULL,
  `sessionID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`sessionID`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessionz`
--

INSERT INTO `sessionz` (`sdate`, `day`, `start_time`, `end_time`, `tutor`, `sessionID`) VALUES
('2020-01-01', 'wednesday', '07:00:00', '09:00:00', 'Arnold', 1),
('2020-01-07', 'tuesday', '10:00:00', '12:00:00', 'Ashwin', 2),
('2020-01-16', 'thursday', '13:00:00', '16:00:00', 'Abhiram', 3),
('2020-01-23', 'Thursday', '10:00:00', '12:00:00', 'Anto', 4),
('2020-01-31', 'friday', '07:00:00', '10:00:00', 'Abhinav', 5),
('2020-02-01', 'saturday', '15:00:00', '17:00:00', 'Ajai', 6),
('2020-02-03', 'monday', '09:00:00', '11:00:00', 'Alexander', 7),
('2020-02-12', 'wednesday', '08:00:00', '10:00:00', 'Nisanth', 8),
('2020-02-21', 'friday', '07:00:00', '10:00:00', 'Alexander', 9),
('2020-03-04', 'wednesday', '07:00:00', '10:00:00', 'Ashwin', 10),
('2020-03-17', 'tuesday', '15:00:00', '17:00:00', 'abhinav', 11),
('2020-03-31', 'tuesday', '09:00:00', '10:00:00', 'Arnold', 12),
('2020-04-01', 'wednesday', '09:00:00', '11:00:00', 'anto', 13),
('2020-04-16', 'thursday', '07:00:00', '10:00:00', 'priyanka', 14),
('2020-04-29', 'Wednesday', '16:00:00', '18:00:00', 'ajai', 15);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `username`, `email`, `password`) VALUES
(2, 'ARNOLD', 'ajarnold540@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(3, 'ARNOLDone', 'ajarnold5401@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(4, 'ARNOLDtwo', 'ajarnold54067@gmail.com', '65a74ae52043d252b8cf82edbe0d1878');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
